Development moved to https://gitlab.com/blacknet-ninja

https://needycoin.org/ aims to continue on Needycoin chain.
